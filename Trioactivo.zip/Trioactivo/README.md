# Motor de Loterías Activo 🎲

Este proyecto es un **motor de predicciones** para tres loterías populares:

- **Trío Activo** → Sorteos de triples (ejemplo: 718).  
- **Loto Activo** → 36 números + 0 y 00.  
- **Guácharo Activo** → 75 números + 0 y 00.  

El motor analiza historiales en **CSV** y genera predicciones de forma automática.

---

## 🚀 Cómo funciona
1. Lee los historiales desde la carpeta `data/`.
2. Analiza frecuencias y patrones con **pandas**.
3. Expone un **API web** con Flask para consultar predicciones.

Ejemplo de endpoints:  
- `/` → mensaje de bienvenida.  
- `/predict/trio` → predicción para Trío Activo.  
- `/predict/loto` → predicción para Loto Activo.  
- `/predict/guacharo` → predicción para Guácharo Activo.  

---

## 📂 Estructura del proyecto

